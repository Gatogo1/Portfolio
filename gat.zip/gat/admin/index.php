<?php include('head/head.php') ?>
<body>
    <!---Tittle bar-->
    <?php include('head/header.php') ?>
    <!--end tittle bar-->
    <div class="container-fluid">

        <div class="row">
       <!---menu-->
<?php include('head/menu.php') ?>

             <div class="content col-sm-10 bg-light">
                <!--info-->
                <?php include('head/info.php') ?>
                <!-- end info-->
                <hr style="background-color: red;">
           
                
                <!---content area --->
                <div class="logo">
        <img style="width: 200px; " src="image/picture1.png" alt="">
    </div>
    <div class="logo">
        <img style="width: 200px; " src="image/Gat-logo.jpg" alt="">
    </div>
                <!---end  content area --->

            </div>

        </div>

    </div>
  
    
        
    </body>
</html>