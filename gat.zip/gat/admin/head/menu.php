 <!--nav--->
 <div class="content col-sm-2 " style="background-color:rgb(14, 1, 43) ;">

               


<div class=" container-fluid nav pt-4">
    <div class="row">
        <div class="   menu col-sm-12">
            <a class=" " href="home" ><i class=" fa fa-dashboard" style="font-size:15px"></i> Dashboard</a> 
         </div>




         <div class="  menu col-sm-12">
            <a   class=" dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-group" style="font-size:15px"></i>   Manage Users </a> 
            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                <a class="dropdown-item" href="#">View Management</a>
                <a class="dropdown-item" href="#">Management Roles</a>
                <a class="dropdown-item" href="#">View Users</a>
              </div>
         </div>



         <div class="  menu col-sm-12">
            <a   class=" dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="	fa fa-info-circle" style="font-size:15px"></i>   My portfolio </a> 
            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                <a class="dropdown-item" href="about">About me</a>
                <a class="dropdown-item" href="experience">Experience </a>
                <a class="dropdown-item" href="contact">Contact </a>
                <a class="dropdown-item" href="project">Projects </a>
               
              </div>
         </div>

       

         

    
    </div>

 </div>

</div>
<!--end nav-->